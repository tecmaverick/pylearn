print("calc init.py loaded")
