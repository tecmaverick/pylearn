def add(fno,sno):
	return int(fno) + int(sno)
