def substract(fno,sno):
	return int(fno) - int(sno)
