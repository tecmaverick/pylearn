def multiply(fno,sno):
	return int(fno) * int(sno)
